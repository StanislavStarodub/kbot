# kbot
My first devops application from scratch in Go + Cobra

Bot's URL: https://t.me/stanislavstarodub_kbot

Install steps:

Run: ./kbot start 
If you see message: no token, then copy from https://t.me/BotFather your token  
type: read -s TELE_TOKEN enter  
insert token  
check it: echo $TELE_TOKEN  
export TELE_TOKEN
type: ./kbot start 
Go to the URL and press Bthe button "start"  
In the dialog box write command: /start hello  
Press "Enter"  
to be cont...